import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';

@Component({
  selector: 'app-add-patient',
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.css']
})
export class AddPatientComponent implements OnInit {

  patientForm : FormGroup;
  added = false;
  constructor(private formBuilder: FormBuilder) {
    this.patientForm = this.formBuilder.group({
      id: [''],
      name: ['',[Validators.required, Validators.minLength(3)]],
      visitedDoctor: ['',Validators.required],
      dateOfVisit: [''],
    });
   }
  isSubmitted = false;
  ngOnInit():void {

  }
  doctors: any = ['David','John','Ricky','Leon','James' ]



  // get f() { return this.patientForm.controls; }
  addPatient(){
    console.log(this.patientForm.value);
    this.isSubmitted = true;
    if(this.patientForm.invalid){
      return;
    }
    console.log("Added")
    this.added = true;
  }

}
