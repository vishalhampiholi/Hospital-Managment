import { Component, OnInit } from '@angular/core';
// import { MatTablepatientList } from '@angular/material/table';
import { Patient } from 'src/models/patient';


@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {

  constructor() { }
  ngOnInit() {
  }

  selectedValue: any;
  displayedColumns: string[] = ['name','specialist','noOfPatients'];
  patientList= PATIENT_LIST;
  status = false;
  patientDetails: Patient[]=[];
  applyFilter() {
  this.status= false
  this.patientDetails= []
  this.patientDetails.push(this.selectedValue)
  this.status = true
}

}


  const PATIENT_LIST:  Patient[] = [
    { id : 1021,name : 'John', age : 35,  visitedDoctor : 21, dateOfVisit : "2021-12-22"},
    {  id : 1022,name : 'Monica',age : 35, visitedDoctor : 21, dateOfVisit : "2021-12-22"},
    { id : 1023 ,name : 'James',age : 35,  visitedDoctor : 21, dateOfVisit : "2021-12-22"},
    {  id : 1024,name : 'Rocky',age : 35, visitedDoctor : 21, dateOfVisit : "2021-12-22"},
  ];
