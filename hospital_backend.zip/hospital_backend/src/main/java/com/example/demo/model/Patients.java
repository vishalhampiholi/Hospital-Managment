package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;
import java.sql.Date;

@Entity
public class Patients {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="patient_id")
    private long id;
    private String name;
    @Column(name="date_of_visit")
    @JsonProperty("DateOfVisit")
    private Date DateOfVisit;

    private int age;
    @Column(name="prescription",columnDefinition="varchar(25) default 'Dolo 650'")
    private String prescription;


    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    @OneToOne
    @JoinColumn(foreignKey=@ForeignKey(name="doctor_id"))
    private Doctor doctor;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public Date getDateOfVisit() {
        return DateOfVisit;
    }

    public void setDateOfVisit(Date DateOfVisit) {
        this.DateOfVisit = DateOfVisit;
    }


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPrescription() {
        return prescription;
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }
}
