import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  selectedValue: any;
  displayedColumns: string[] = ['name','specialist','noOfPatients'];
  doctorList=  DOCTOR_LIST;
  status = false;
  doctorDetails: Doctor[]=[];
  onChange() {
  this.status= false
  this.doctorDetails= []
  this.doctorDetails.push(this.selectedValue)
  this.status = true
}

}

export interface Doctor {
  name : string;
  age : number;
  gender : string;
  specialist : string;
  noOfPatients : number;
}
  const DOCTOR_LIST :  Doctor[] = [
    { name : 'John', age : 35, gender : 'Male', specialist : 'Brain' , noOfPatients : 3 },
    { name : 'David',age : 35, gender : 'Male', specialist : 'Brain'  , noOfPatients : 3},
    { name : 'James',age : 35, gender : 'Male', specialist : 'Brain' , noOfPatients : 3 },
    { name : 'Rocky',age : 35, gender : 'Male', specialist : 'Brain'  , noOfPatients : 3},
  ];
