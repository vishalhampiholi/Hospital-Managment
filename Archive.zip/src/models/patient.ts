export interface Patient{
    id:number;
    name:string;
    age:number;
    visitedDoctor:number;
    dateOfVisit:string;
  }